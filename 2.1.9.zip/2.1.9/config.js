// var _config = {
// 	baseUrl: 'http://localhost/chrome_ext',
// 	apiBaseUrl: 'http://127.0.0.1:8001/api',
// 	planLimit:150,
// 	upgradeUrl: 'https://www.upgradedream100.com'
// }
var _config = {
	baseUrl: 'https://dream100software.com',
	apiBaseUrl: 'https://dream100software.com/api',
	planLimit:150,
	upgradeUrl: 'https://www.upgradedream100.com'
}